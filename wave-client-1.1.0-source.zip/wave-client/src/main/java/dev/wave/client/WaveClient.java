package dev.wave.client;

import dev.wave.client.module.WaveModules;
import dev.wave.client.ui.WaveScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class WaveClient implements ClientModInitializer {
    public static final String MOD_ID = "wave";
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        WaveModules.init();
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.wave.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.wave"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new WaveScreen());
            }
            WaveModules.tick(client);
        });

        HudRenderCallback.EVENT.register(WaveClient::renderHud);
    }

    private static void renderHud(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;

        int y = 8;
        context.drawTextWithShadow(client.textRenderer, "WAVE AUTOPLAY", 8, y, 0xFF8BD5FF);
        y += 12;
        if (WaveModules.showFps) {
            context.drawTextWithShadow(client.textRenderer, "FPS: " + client.getCurrentFps(), 8, y, 0xFFFFFFFF);
            y += 11;
        }
        if (WaveModules.showCoordinates) {
            var pos = client.player.getBlockPos();
            context.drawTextWithShadow(client.textRenderer,
                    "XYZ: " + pos.getX() + " / " + pos.getY() + " / " + pos.getZ(), 8, y, 0xFFFFFFFF);
            y += 11;
        }
        if (WaveModules.autoWalk) context.drawTextWithShadow(client.textRenderer, "AUTO WALK", 8, y, 0xFF8BD5FF);
    }
}
