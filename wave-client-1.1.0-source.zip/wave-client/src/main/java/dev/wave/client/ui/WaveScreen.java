package dev.wave.client.ui;

import dev.wave.client.module.WaveModules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class WaveScreen extends Screen {
    public WaveScreen() { super(Text.literal("Wave AutoPlay")); }

    @Override
    protected void init() {
        int x = width / 2 - 105;
        int y = height / 2 - 82;
        int w = 210;
        int h = 20;
        int gap = 24;

        addDrawableChild(ButtonWidget.builder(label("Auto Walk", WaveModules.autoWalk), b -> {
            WaveModules.autoWalk = !WaveModules.autoWalk;
            b.setMessage(label("Auto Walk", WaveModules.autoWalk));
        }).dimensions(x, y, w, h).build());
        addDrawableChild(ButtonWidget.builder(label("Auto Sprint", WaveModules.autoSprint), b -> {
            WaveModules.autoSprint = !WaveModules.autoSprint;
            b.setMessage(label("Auto Sprint", WaveModules.autoSprint));
        }).dimensions(x, y + gap, w, h).build());
        addDrawableChild(ButtonWidget.builder(label("Auto Eat", WaveModules.autoEat), b -> {
            WaveModules.autoEat = !WaveModules.autoEat;
            b.setMessage(label("Auto Eat", WaveModules.autoEat));
        }).dimensions(x, y + gap * 2, w, h).build());
        addDrawableChild(ButtonWidget.builder(label("FPS HUD", WaveModules.showFps), b -> {
            WaveModules.showFps = !WaveModules.showFps;
            b.setMessage(label("FPS HUD", WaveModules.showFps));
        }).dimensions(x, y + gap * 3, w, h).build());
        addDrawableChild(ButtonWidget.builder(label("Coordinates", WaveModules.showCoordinates), b -> {
            WaveModules.showCoordinates = !WaveModules.showCoordinates;
            b.setMessage(label("Coordinates", WaveModules.showCoordinates));
        }).dimensions(x, y + gap * 4, w, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x, y + gap * 5 + 3, w, h).build());
    }

    private static Text label(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 105, 0xFF8BD5FF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Local single-player automation"), width / 2, height / 2 + 72, 0xFFAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
