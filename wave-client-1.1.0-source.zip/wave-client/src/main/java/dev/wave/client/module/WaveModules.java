package dev.wave.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

public final class WaveModules {
    public static boolean showFps = true;
    public static boolean showCoordinates = true;
    public static boolean autoWalk = false;
    public static boolean autoSprint = false;
    public static boolean autoEat = false;

    private static int previousSlot = -1;
    private static int eatCooldown = 0;

    private WaveModules() {}

    public static void init() {
        showFps = true;
        showCoordinates = true;
        autoWalk = false;
        autoSprint = false;
        autoEat = false;
        previousSlot = -1;
        eatCooldown = 0;
    }

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            releaseMovement(client);
            return;
        }

        // Automation is deliberately limited to local single-player worlds.
        if (!client.isInSingleplayer()) {
            releaseMovement(client);
            return;
        }

        client.options.forwardKey.setPressed(autoWalk);
        if (autoSprint) client.player.setSprinting(autoWalk);

        if (eatCooldown > 0) eatCooldown--;
        PlayerEntity player = client.player;
        if (autoEat && eatCooldown == 0 && player.getHungerManager().getFoodLevel() <= 14
                && !player.isUsingItem()) {
            int foodSlot = findFoodSlot(player);
            if (foodSlot >= 0) {
                previousSlot = player.getInventory().selectedSlot;
                player.getInventory().selectedSlot = foodSlot;
                if (client.interactionManager != null) {
                    client.interactionManager.interactItem(player, Hand.MAIN_HAND);
                }
                eatCooldown = 20;
            }
        }

        if (previousSlot >= 0 && !player.isUsingItem() && eatCooldown == 0) {
            player.getInventory().selectedSlot = previousSlot;
            previousSlot = -1;
        }
    }

    private static int findFoodSlot(PlayerEntity player) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = player.getInventory().getStack(slot);
            if (!stack.isEmpty() && stack.isFood()) return slot;
        }
        return -1;
    }

    public static void releaseMovement(MinecraftClient client) {
        client.options.forwardKey.setPressed(false);
        if (client.player != null && autoSprint) client.player.setSprinting(false);
    }
}
