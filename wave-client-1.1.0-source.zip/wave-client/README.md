# Wave AutoPlay 1.1.0

A touch-friendly Fabric client mod for Minecraft Java Edition 1.21.1.

## Included modules

- **Auto Walk** — holds forward while enabled.
- **Auto Sprint** — sprints while Auto Walk is enabled.
- **Auto Eat** — selects food from the hotbar when hunger is 14 or lower, then restores the previous slot.
- **FPS HUD** and **Coordinates HUD**.
- **In-game GUI** — all toggles are buttons; no chat commands are used.

Automation runs only in local single-player worlds. In multiplayer, automation is disabled and movement input is released.

## Build

Requirements: JDK 21 and Gradle 8.x.

```bash
gradle build
```

The mod jar is written to `build/libs/`.

## Install

Install Fabric Loader for Minecraft 1.21.1, then place the built `wave-client-1.1.0.jar` in the instance's `mods` folder. Fabric API is required.

## Controls

- **Right Shift** — open the Wave AutoPlay menu.
- Use the on-screen buttons to toggle modules. The menu is mouse/touch operable.

This is a Fabric Java Edition mod, not an Android APK. Mobile Java launchers that support Fabric 1.21.1 can load it.
